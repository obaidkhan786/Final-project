﻿namespace WindowsFormsApp8
{
    partial class RemoveSpvis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.manage_spvvis = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // manage_spvvis
            // 
            this.manage_spvvis.FormattingEnabled = true;
            this.manage_spvvis.Location = new System.Drawing.Point(21, 86);
            this.manage_spvvis.Name = "manage_spvvis";
            this.manage_spvvis.Size = new System.Drawing.Size(239, 160);
            this.manage_spvvis.TabIndex = 31;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(171, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "Deleat supervisor";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(52, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(173, 24);
            this.label5.TabIndex = 29;
            this.label5.Text = "Remove supervisor";
            // 
            // RemoveSpvis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 315);
            this.Controls.Add(this.manage_spvvis);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Name = "RemoveSpvis";
            this.Text = "RemoveSpvis";
            this.Load += new System.EventHandler(this.RemoveSpvis_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox manage_spvvis;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
    }
}