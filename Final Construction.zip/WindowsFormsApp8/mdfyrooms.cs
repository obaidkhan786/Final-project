﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class mdfyrooms : Form
    {
        public mdfyrooms()
        {
            InitializeComponent();
        }
        DataClasses2DataContext d1 = new DataClasses2DataContext();

        private void mdfyrooms_Load(object sender, EventArgs e)
        {
            
                // TODO: This line of code loads data into the 'labfinalDataSet.tables' table. You can move, or remove it, as needed.
              //  this.tablesTableAdapter.Fill(this.labfinalDataSet.tblroom);
                //table tbl = new table();

                mdfygrid.DataSource = d1.tblrooms;
                mdfygrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
        private void mdfygrid_SelectionChanged(object sender, EventArgs e)
        {
            var rowsCount = mdfygrid.SelectedRows.Count;
            if (rowsCount == 0 || rowsCount > 1) return;

            var row = mdfygrid.SelectedRows[0];

            if (row == null) return;

            txt_id.Text = row.Cells[0].Value.ToString();
            txt_rmtype.Text = row.Cells[1].Value.ToString();
            chk_avail.Checked = row.Cells[2].Value == null ? false : Convert.ToBoolean(row.Cells[2].Value.ToString());

        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            DataGridViewRow dr = mdfygrid.CurrentRow;
         //   table t1 = d1.tblrooms.First(i => i.id == Convert.ToInt32(dr.Cells[0].Value.ToString()));

            //t1.id = Convert.ToInt32(txt_id.Text;

          //  t1.seatno = txt_rmtype.Text;
          //  t1.isavalible = chk_avail.Checked;

            d1.SubmitChanges();
            //loadData();
            mdfygrid.DataSource = d1.tblrooms;
            MessageBox.Show("Record Seccessfully Updated");

        }
    }
}
