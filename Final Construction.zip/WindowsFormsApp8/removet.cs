﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class removet : Form
    {
        public removet()
        {
            InitializeComponent();
        }

        public SqlDataReader SqlDataReader { get; private set; }

        private void button1_Click(object sender, EventArgs e)
        {
           
                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand("Delete from tables where id = '" + mange_table.SelectedItem + "'", conn);
            try
            {
                conn.Open();

                comm.ExecuteNonQuery();
                conn.Close();
                updatetable();
                MessageBox.Show("Table Deleted");
            }

            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void removet_Load(object sender, EventArgs e)
        {
            updatetable();
        }

        private void updatetable()
        {
            try
            {
                mange_table.Items.Clear();
                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand("Select * from tables", conn);

                conn.Open();

                SqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    mange_table.Items.Add(reader["id"]);

                }
                conn.Close();
            }

            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private void mange_table_Click(object sender, EventArgs e)
        {
           
        }
    }
}
