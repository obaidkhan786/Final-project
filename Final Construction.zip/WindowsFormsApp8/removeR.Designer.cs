﻿namespace WindowsFormsApp8
{
    partial class removeR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mange_room = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mange_room
            // 
            this.mange_room.FormattingEnabled = true;
            this.mange_room.Location = new System.Drawing.Point(63, 80);
            this.mange_room.Name = "mange_room";
            this.mange_room.Size = new System.Drawing.Size(239, 147);
            this.mange_room.TabIndex = 29;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(204, 264);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 28;
            this.button1.Text = "Remove Room";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(113, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 24);
            this.label5.TabIndex = 27;
            this.label5.Text = "Remove Room";
            // 
            // removeR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 313);
            this.Controls.Add(this.mange_room);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Name = "removeR";
            this.Text = "removeR";
            this.Load += new System.EventHandler(this.removeR_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox mange_room;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
    }
}