﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class removeR : Form
    {
        public removeR()
        {
            InitializeComponent();
        }
        private void updatetable()
        {
            try
            {
                mange_room.Items.Clear();
                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand("Select * from tblroom", conn);

                conn.Open();

                SqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    mange_room.Items.Add(reader["id"]);

                }
                conn.Close();
            }

            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }
        private void removeR_Load(object sender, EventArgs e)
        {
            updatetable();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {

                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand("Delete from tblroom where id = '" + mange_room.SelectedItem + "'", conn);
                try
                {
                    conn.Open();

                    comm.ExecuteNonQuery();
                    conn.Close();
                    updatetable();
                    MessageBox.Show("Room Deleted");
                }

                catch (Exception x)
                {
                    MessageBox.Show(x.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

        }
    }
}
