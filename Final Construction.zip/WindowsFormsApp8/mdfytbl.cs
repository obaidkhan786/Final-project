﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class mdfytbl : Form
    {
        public mdfytbl()
        {
            InitializeComponent();

        }

        DataClasses1DataContext d1 = new DataClasses1DataContext();

        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewRow dr = mdfygrid.CurrentRow;
            table t1 = d1.tables.First(i => i.id == Convert.ToInt32(dr.Cells[0].Value.ToString()));

            //t1.id = Convert.ToInt32(txt_id.Text;

            t1.seatno = txt_seatno.Text;
            t1.isavalible = chk_avail.Checked;
            
            d1.SubmitChanges();
            //loadData();
            mdfygrid.DataSource = d1.tables;
            MessageBox.Show("Record Seccessfully Updated");

        }
        private void mdfytbl_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'labfinalDataSet.tables' table. You can move, or remove it, as needed.
            this.tablesTableAdapter.Fill(this.labfinalDataSet.tables);
            //table tbl = new table();

            mdfygrid.DataSource = d1.tables;
            mdfygrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mdfygrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void mdfygrid_SelectionChanged(object sender, EventArgs e)
        {
            var rowsCount = mdfygrid.SelectedRows.Count;
            if (rowsCount == 0 || rowsCount > 1) return;

            var row = mdfygrid.SelectedRows[0];

            if (row == null) return;

            txt_id.Text = row.Cells[0].Value.ToString();
            txt_seatno.Text = row.Cells[1].Value.ToString();
            chk_avail.Checked = row.Cells[2].Value == null ? false : Convert.ToBoolean(row.Cells[2].Value.ToString());
           
        }
    }
}
