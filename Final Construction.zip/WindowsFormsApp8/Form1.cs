﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addtable at = new addtable();
            at.MdiParent = this;
            at.Show();
        }

        private void addSupervisorToolStripMenuItem_Click(object sender, EventArgs e)
        {

            addspvis a = new addspvis();
            a.MdiParent = this;
            a.Show();


        }

        private void removeTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            removet rt = new removet();
            rt.MdiParent = this;
            rt.Show();
        }

        private void removeSupervisorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RemoveSpvis rs = new RemoveSpvis();
            rs.MdiParent = this;
            rs.Show();

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addroom ar = new addroom();
            ar.MdiParent = this;
            ar.Show();
        }

        private void removeRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            removeR rR = new removeR();
            rR.MdiParent = this;
            rR.Show();
        }

        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mdfyrooms mR = new mdfyrooms();
            mR.MdiParent = this;
            mR.Show();
        }

        private void tablesToolStripMenuItem_Click(object sender, EventArgs e)
        {

            mdfytbl mT = new mdfytbl();
            mT.MdiParent = this;
            mT.Show();
        }

        private void inventoryToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    }

