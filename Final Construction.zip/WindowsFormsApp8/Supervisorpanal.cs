﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Supervisorpanal : Form
    {
        public Supervisorpanal()
        {
            InitializeComponent();
        }

        private void Supervisorpanal_Load(object sender, EventArgs e)
        {

        }

        private void Supervisorpanal_Load_1(object sender, EventArgs e)
        {
            try
            {
                //avail_table.Items.Clear();
                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand("Select id,seatno from [tables] where isavalible = 0 or isavalible is null", conn);

                conn.Open();

                SqlDataReader reader = comm.ExecuteReader();
                var dataTable = new DataTable();
                dataTable.Load(reader);
                //while (reader.Read())
                //{
                //    //avail_table.Items.Add(reader["id"]);

                //}
                grid_tables.DataSource = dataTable;
                grid_tables.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                btn_bktbl.Enabled = false;
                conn.Close();
            }

            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private void avail_table_SelectedIndexChanged(object sender, EventArgs e)
        {
             
        }

        private void avail_table_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


                var i = Convert.ToInt32(grid_tables.SelectedRows[0].Cells[0].Value);
               
                addcustomer ac = new addcustomer(i);
                // ac.MdiParent = this;
                ac.Show();
                this.Close();
                // this.Hide();
            }
            catch
            {
                

            }


        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            spPannal f2 = new spPannal();
            f2.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void grid_tables_SelectionChanged(object sender, EventArgs e)
        {
            btn_bktbl.Enabled = true;
        }

        private void Supervisorpanal_FormClosing(object sender, FormClosingEventArgs e)
        {
         
        }

        private void Supervisorpanal_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

        private void grid_tables_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
