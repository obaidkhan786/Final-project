﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class loginforsp : Form
    {
        public loginforsp()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {




            bool IsUserFound = false;
            if (txt_name.Text == "" && txt_pass.Text == "")
            {
                MessageBox.Show("Enter Correct Name And Password ");
            }


            else
            {
                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand();
                comm.CommandText = "[loginsp]";
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@name", txt_name.Text);
                comm.Parameters.AddWithValue("@code", txt_pass.Text);
                comm.Connection = conn;
                try
                {
                    conn.Open();
                    SqlDataReader reader = comm.ExecuteReader();
                    while (reader.Read())
                    {
                        IsUserFound = true;
                        spPannal mainform = new spPannal();
                        mainform.Show();
                        this.Hide();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                if (!IsUserFound)
                {
                    MessageBox.Show("InValid UserName OR Password");
                }
            }

        }

       

        private void loginforsp_Load(object sender, EventArgs e)
        {

        }

        private void loginforsp_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }
    }
}
