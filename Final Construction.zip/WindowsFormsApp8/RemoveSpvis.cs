﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class RemoveSpvis : Form
    {
        public RemoveSpvis()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand("Delete from [user] where name = '" + manage_spvvis.SelectedItem + "'", conn);
            try
            {
                conn.Open();

                comm.ExecuteNonQuery();
                conn.Close();
                updatetable();
                MessageBox.Show("Supervisor Removed");
            }

            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void updatetable()
        {
            try
            {
                manage_spvvis.Items.Clear();
                var conn = new SqlConnection("Data Source=DESKTOP-G9FGO99;Initial Catalog=labfinal;Integrated Security=True");
                var comm = new SqlCommand("Select * from [user]", conn);

                conn.Open();

                SqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    manage_spvvis.Items.Add(reader["name"]);

                }
                conn.Close();
            }

            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        private void RemoveSpvis_Load(object sender, EventArgs e)
        {
            updatetable();
        }
    }
}
